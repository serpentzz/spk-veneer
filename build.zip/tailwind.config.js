/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./build/*.{php,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

